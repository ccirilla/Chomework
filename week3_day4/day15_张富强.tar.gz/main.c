#include "func.h"

int main(int argc, char *argv[])
{
	ARGS_CHECK(argc,4);
	int child_num = atoi(argv[3]);
	process_data *pChild = (process_data *)calloc(child_num,sizeof(process_data));
	make_child(pChild,child_num);
	int socket_fd;
	int i,j,ret;
	tcp_init(&socket_fd,argv[1],argv[2]);
	int epfd = epoll_create(1);
	struct epoll_event event,evs[child_num + 1];
	event.events = EPOLLIN;
	event.data.fd = socket_fd;
	epoll_ctl(epfd,EPOLL_CTL_ADD,socket_fd,&event);
	for(i=0;i<child_num;i++)
	{
		event.data.fd = pChild[i].fd;
		epoll_ctl(epfd,EPOLL_CTL_ADD,pChild[i].fd,&event);
	}
	while(1)
	{
		int read_num = epoll_wait(epfd,evs,child_num+1,-1);
		for(i=0;i<read_num;i++)
		{
			if(evs[i].data.fd == socket_fd)
			{
				int new_fd = accept(socket_fd,NULL,NULL);
				for(j = 0;j<child_num;j++)
				{
					if(pChild[j].busy == 0)
						{
							ret = send_fd(pChild[j].fd,new_fd);
							ERROR_CHECK(ret,-1,"send_fd");
							printf("%d chilid is busy \n",pChild[j].pid);
							pChild[i].busy = 1;
							break;
						}
				}
				close(new_fd);
			}else 
			{
				for(j = 0;j<child_num;j++)
				{
					if(evs[i].data.fd == pChild[j].fd)
					{
						read(pChild[i].fd,&ret,4);
						printf("%d chilid is not busy \n",pChild[j].pid);
						pChild[i].busy = 0;
						break;
					}
				}
			}
		}
	}
	return 0;
}

