#include <func.h>

int main(int argc,char *argv[])
{
	ARGS_CHECK(argc,3);
	int cfd = socket(AF_INET,SOCK_STREAM,0);
	struct sockaddr_in ser;
	bzero(&ser,sizeof(ser));
	ser.sin_family = AF_INET;
	ser.sin_port = htons(atoi(argv[2]));
	ser.sin_addr.s_addr = inet_addr(argv[1]);
	int ret = connect(cfd,(struct sockaddr*)&ser,sizeof(ser));
	ERROR_CHECK(ret,-1,"connect");
	int len,totle = 0;
	char buf[2000];
	bzero(buf,sizeof(buf));
	recv(cfd,&len,4,0);
	recv(cfd,buf,len,0);
	int fd = open(buf,O_CREAT|O_WRONLY,0666);
	ERROR_CHECK(fd,-1,"open");
	int j=0,k;
	while(1)
	{
		ret = recv(cfd,&len,4,0);
		ERROR_CHECK(ret,-1,"recv");	
		if(len !=0)
		{
			totle += len;
			k = totle/5;
			if(k>j)
			{
				printf("已下载 %d \n",k);
				j = k;
			}
			ret = recv(cfd,buf,len,0);
			ERROR_CHECK(ret,-1,"recv");	
			write(fd,buf,len);
		}else
			break;
	}
	printf("下载完成\n");
	close(fd);
	close(cfd);
	return 0;
}


