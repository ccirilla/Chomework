#include <func.h>

int main()
{
	printf("%*s%s\n",10,"","hello");
}
