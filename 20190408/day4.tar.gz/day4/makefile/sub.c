int sub(int i,int j)
{
	return i-j;
}
