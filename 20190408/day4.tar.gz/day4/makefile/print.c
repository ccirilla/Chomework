#include <stdio.h>

void print()
{
	printf("I am print function\n");
	return;
}
