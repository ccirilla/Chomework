#include <func.h>

void print()
{
	printf("I am print\n");
	return;
}

int main()
{
	print();
	printf("I am main\n");
	return 0;
}
